(function (document, $) {
    "use strict";

	$(document).on("click", ".submitNum", function (e) {

        var answer = Number($("#answer").text());
        if(!answer) {
			alert("请先设置中奖数字。");
            return;
        }

        var inputNum = Number($("#inputNum").val());
        var result;

        if(inputNum > answer) {
			result = "太大了";
        } else if(inputNum < answer) {
			result = "太小了";
        } else {
			result = "猜对了";
            $("#answer").show();
        }

		showResult(result);

    });

    function showResult(result) {
        var $result = $(".result");
		$result.text("");
		setTimeout(function(){$result.text(result); }, 100);
    }



})(document, Granite.$);
